<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTableHarimahasiswa extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('harimahasiswa', function (Blueprint $table) {
            // Create tabel waktu_mahasiswa
            $table->integer('id_mahasiswa')->unsigned()->index();
            $table->integer('id_hari')->unsigned()->index();
            $table->timestamps();

            // Set PK
            $table->primary(['id_mahasiswa', 'id_hari']);

            // Set FK waktu_mahasiswa --- mahasiswa
            $table->foreign('id_mahasiswa')
                  ->references('id')
                  ->on('mahasiswa')
                  ->onDelete('cascade')
                  ->onUpdate('cascade');

            // Set FK waktu_mahasiswa --- waktu
            $table->foreign('id_hari')
                  ->references('id')
                  ->on('hari')
                  ->onDelete('cascade')
                  ->onUpdate('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('harimahasiswa');
    }
}











