<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTableHaripenguji extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('haripenguji', function (Blueprint $table) {
            // Create tabel waktu_penguji
            $table->integer('id_penguji')->unsigned()->index();
            $table->integer('id_hari')->unsigned()->index();
            $table->timestamps(); 

            // Set PK
            $table->primary(['id_penguji', 'id_hari']);

            // Set FK waktu_penguji --- penguji
            $table->foreign('id_penguji')
                  ->references('id')
                  ->on('penguji')
                  ->onDelete('cascade')
                  ->onUpdate('cascade');

            // Set FK waktu_penguji --- waktu
            $table->foreign('id_hari')
                  ->references('id')
                  ->on('hari')
                  ->onDelete('cascade')
                  ->onUpdate('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('haripenguji');
    }
}
