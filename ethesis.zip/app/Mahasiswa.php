<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Mahasiswa extends Model
{
    protected $table = 'mahasiswa';
    protected $dates = ['tanggal_lahir'];

    protected $fillable = [
        'nim',
        'nama_mahasiswa',
        'tanggal_lahir',
        'jenis_kelamin',
        'jdl_skripsi',
        'foto'
    ]; 

    
    public function hari() {
        return $this->belongsToMany('App\Hari', 'harimahasiswa', 'id_mahasiswa', 'id_hari')->withTimeStamps();
    }

    public function harimahasiswa() {
        return $this->belongsToMany('App\HariMahasiswa', 'harimahasiswa', 'id_mahasiswa', 'id_hari')->withTimeStamps();
    }



}
