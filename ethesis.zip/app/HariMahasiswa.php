<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class HariMahasiswa extends Model
{
    protected $table = 'harimahasiswa';
    protected $fillable = [
    	'id_mahasiswa',
		'id_hari'
		];
        
        public function mahasiswa() {
            return $this->belongsToMany(Mahasiswa::class, 'harimahasiswa','id_mahasiswa', 'id_hari')->withTimeStamps();
        }
        public function hari() {
            return $this->belongsToMany('App\Hari', 'harimahasiswa', 'id_mahasiswa', 'id_hari')->withTimeStamps();
        }
}
