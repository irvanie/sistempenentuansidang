<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Penguji extends Model
{
    protected $table = 'penguji';
    protected $dates = ['tanggal_lahir'];

    protected $fillable = [
        'nip',
        'nama_penguji',
        'tanggal_lahir',
        'jenis_kelamin',
        'foto'
    ]; 

    public function hari() {
        return $this->belongsToMany('App\Hari', 'haripenguji', 'id_penguji', 'id_hari')->withTimeStamps();
    }

    public function waktupenguji() {
        return $this->hasmany('App\WaktuPenguji','id');
    }
}
