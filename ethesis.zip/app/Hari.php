<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Hari extends Model
{
    protected $table = 'hari';

    protected $fillable = ['nama_hari'];

    public function mahasiswa() {
        return $this->belongsToMany('App\Mahasiswa', 'harimahasiswa', 'id_hari', 'id_mahasiswa');
    }

    public function waktusidang() {
        return $this->hasmany('App\WaktuSidang','id');
    }
   
}
