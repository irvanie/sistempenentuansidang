<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class WaktuSidangRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'hari'          => 'required|string|max:30',
            'mulai'         => 'required|date_format:"H:i"',
            'selesai'       => 'required|date_format:"H:i"',
            'sesi'          => 'required|string|max:30',
        ];
    }
}
