<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests\HariRequest;
use App\Hari;
use Session;

class HariController extends Controller
{
    public function __construct() {
        $this->middleware('auth');
        $this->middleware('admin');
    }

    public function index() {
        $hari_list = Hari::all();
        return view('hari.index', compact('hari_list'));
    }

    public function create() {
        return view('hari.create');
    }

    public function store(HariRequest $request) {
        Hari::create($request->all());
        Session::flash('flash_message', 'Data Hari berhasil disimpan.');
        return redirect('hari');
    }

    public function edit(Hari $hari) {
        return view('hari.edit', compact('hari'));
    }

    public function update(Hari $hari, HariRequest $request) {
        $hari->update($request->all());
        Session::flash('flash_message', 'Data hari berhasil diupdate.');
        return redirect('hari');
    }

    public function destroy(Hari $hari) {
        $hari->delete();
        Session::flash('flash_message', 'Data hari berhasil dihapus.');
        Session::flash('penting', true);
        return redirect('hari');
    }
}
