<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests\MahasiswaRequest;
use App\Mahasiswa;
use Illuminate\Support\Facades\Storage;
use Session;

class MahasiswaController extends Controller
{
    public function __construct() {
        $this->middleware('auth');
        $this->middleware('mahasiswa');
        
    }

    /*
    | -------------------------------------------------------------------------------------------------------
    | INDEX
    | -------------------------------------------------------------------------------------------------------
    */
    public function index() {
        $mahasiswa_list   = Mahasiswa::paginate(5);
        $jumlah_mahasiswa = Mahasiswa::count();
        return view('mahasiswa.index', compact('mahasiswa_list', 'jumlah_mahasiswa'));
    }


    /*
    | -------------------------------------------------------------------------------------------------------
    | SHOW DETAIL
    | -------------------------------------------------------------------------------------------------------
    */
    public function show(Mahasiswa $mahasiswa) {
        return view('mahasiswa.show', compact('mahasiswa'));
    }


    /*
    | -------------------------------------------------------------------------------------------------------
    | CREATE
    | -------------------------------------------------------------------------------------------------------
    */
    public function create() {
        return view('mahasiswa.create');
    }


    /*
    | -------------------------------------------------------------------------------------------------------
    | EDIT
    | -------------------------------------------------------------------------------------------------------
    */
    public function edit(Mahasiswa $mahasiswa) {
        

        return view('mahasiswa.edit', compact('mahasiswa'));
    }


    /*
    | -------------------------------------------------------------------------------------------------------
    | CREATE
    | -------------------------------------------------------------------------------------------------------
    */
    public function store(MahasiswaRequest $request) {
        $input = $request->all();

        // Upload foto.
        if ($request->hasFile('foto')) {
            $input['foto'] = $this->uploadFoto($request);
        }

        // Insert Mahasiswa.
        $mahasiswa = Mahasiswa::create($input);


        // Flass message.
        Session::flash('flash_message', 'Data Mahasiswa berhasil disimpan.');

        return redirect('mahasiswa');
    }


    /*
    | -------------------------------------------------------------------------------------------------------
    | UPDATE
    | -------------------------------------------------------------------------------------------------------
    */
    public function update(Mahasiswa $mahasiswa, MahasiswaRequest $request) {
        $input = $request->all();

        // Update foto.
        if ($request->hasFile('foto')) {
            $input['foto'] = $this->updateFoto($mahasiswa, $request);
        }
        
        // Update Mahasiswa.
        $mahasiswa->update($input);

        // Flash message.
        Session::flash('flash_message', 'Data Mahasiswa berhasil diupdate.');

        return redirect('mahasiswa');
    }


    /*
    | -------------------------------------------------------------------------------------------------------
    | DESTROY / DELETE
    | -------------------------------------------------------------------------------------------------------
    */
    public function destroy(Mahasiswa $mahasiswa) {
        // Hapus foto kalau ada.
        $this->hapusFoto($mahasiswa);

        $mahasiswa->delete();

        // Flash message.
        Session::flash('flash_message', 'Data Mahasiswa berhasil dihapus.');
        Session::flash('penting', true);

        return redirect('mahasiswa');
    }


    /*
    | -------------------------------------------------------------------------------------------------------
    | CARI
    | -------------------------------------------------------------------------------------------------------
    */
    // public function cari(Request $request) {
    //     $kata_kunci = trim($request->input('kata_kunci'));

    //     if (! empty($kata_kunci)) {
    //         $jenis_kelamin = $request->input('jenis_kelamin');
    //         $id_kelas = $request->input('id_kelas');

    //         // Query
    //         $query = Siswa::where('nama_siswa', 'LIKE', '%' . $kata_kunci . '%');
    //         (! empty($jenis_kelamin)) ? $query->JenisKelamin($jenis_kelamin) : '';
    //         (! empty($id_kelas)) ? $query->Kelas($id_kelas) : '';

    //         $siswa_list = $query->paginate(2);

    //         // URL Links pagination
    //         $pagination = (! empty($jenis_kelamin)) ? $siswa_list->appends(['jenis_kelamin' => $jenis_kelamin]) : '';
    //         $pagination = (! empty($id_kelas)) ? $pagination = $siswa_list->appends(['id_kelas' => $id_kelas]) : '';
    //         $pagination = $siswa_list->appends(['kata_kunci' => $kata_kunci]);

    //         $jumlah_siswa = $siswa_list->total();
    //         return view('siswa.index', compact('siswa_list', 'kata_kunci', 'pagination', 'jumlah_siswa', 'id_kelas', 'jenis_kelamin'));
    //     }

    //     return redirect('siswa');
    // }


    /*
    | -------------------------------------------------------------------------------------------------------
    | INSERT TELEPON
    | -------------------------------------------------------------------------------------------------------
    */
    // private function insertTelepon(Siswa $siswa, SiswaRequest $request) {
    //     $telepon = new Telepon;
    //     $telepon->nomor_telepon = $request->input('nomor_telepon');
    //     $siswa->telepon()->save($telepon);
    // }


    /*
    | -------------------------------------------------------------------------------------------------------
    | UPDATE TELEPON
    | -------------------------------------------------------------------------------------------------------
    */
    // private function updateTelepon(Siswa $siswa, SiswaRequest $request) {
    //     if ($siswa->telepon) {
    //         // Jika telp diisi, update.
    //         if ($request->filled('nomor_telepon')) {
    //             $telepon = $siswa->telepon;
    //             $telepon->nomor_telepon = $request->input('nomor_telepon');
    //             $siswa->telepon()->save($telepon);
    //         }
            // Jika telp tidak diisi, hapus.
        //     else {
        //         $siswa->telepon()->delete();
        //     }
        // }
        // Buat entry baru, jika sebelumnya tidak ada no telp.
    //     else {
    //         if ($request->filled('nomor_telepon')) {
    //             $telepon = new Telepon;
    //             $telepon->nomor_telepon = $request->input('nomor_telepon');
    //             $siswa->telepon()->save($telepon);
    //         }
    //     }
    // }


    /*
    | -------------------------------------------------------------------------------------------------------
    | UPLOAD FOTO
    | -------------------------------------------------------------------------------------------------------
    */
    private function uploadFoto(MahasiswaRequest $request) {
        $foto = $request->file('foto');
        $ext  = $foto->getClientOriginalExtension();

        if ($request->file('foto')->isValid()) {
            $foto_name   = date('YmdHis'). ".$ext";
            $request->file('foto')->move('fotoupload', $foto_name);
            return $foto_name;
        }
        return false;
    }

    /*
    | -------------------------------------------------------------------------------------------------------
    | UPDATE FOTO
    | -------------------------------------------------------------------------------------------------------
    */
    private function updateFoto(Mahasiswa $mahasiswa, MahasiswaRequest $request) {
        // Jika user mengisi foto.
        if ($request->hasFile('foto')) {
            // Hapus foto lama jika ada foto baru.
            $exist = Storage::disk('foto')->exists($mahasiswa->foto);
            if (isset($mahasiswa->foto) && $exist) {
                $delete = Storage::disk('foto')->delete($mahasiswa->foto);
            }

            // Upload foto baru.
            $foto = $request->file('foto');
            $ext  = $foto->getClientOriginalExtension();
            if ($request->file('foto')->isValid()) {
                $foto_name   = date('YmdHis'). ".$ext";
                $upload_path = 'fotoupload';
                $request->file('foto')->move($upload_path, $foto_name);
                return $foto_name;
            }
        }
    }


    /*
    | -------------------------------------------------------------------------------------------------------
    | HAPUS FOTO
    | -------------------------------------------------------------------------------------------------------
    */
    private function hapusFoto(Mahasiswa $mahasiswa) {
        $is_foto_exist = Storage::disk('foto')->exists($mahasiswa->foto);

        if ($is_foto_exist) {
            Storage::disk('foto')->delete($mahasiswa->foto);
        }
    }
}
