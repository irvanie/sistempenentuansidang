<?php

namespace App\Http\Controllers;

use App\Ruangan;
use App\WaktuMahadosen;
use App\WaktuMahasiswa;
use App\WaktuPenguji;
use App\WaktuSidang;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class JadwalController extends Controller
{
    var $num_crommosom = 6;
    var $ruang = array();
    var $waktuSiswa = array();
    var $currentUsed = array();
    var $generation = 0;
    var $max_generation = 25;
    var $crommosom = array();
    var $per_sks = 45;
    var $success = false;
    var $debug = true;
    var $fitness = array();
    var $console = "";
    var $total_fitness = 0;
    var $probability  = array();
    var $com_pro = array();
    var $rand = array();
    var $parent = array();
    var $show_log= false;

    var $best_fitness = 0;
    var $best_cromossom = array();

    var $crossover_rate = 75;
    var $mutation_rate = 25;

    var $_strtotime = array();
    var $_timeclash = array();

    var $time_start;
    var $time_end;

    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('admin');
        $this->ruang    = Ruangan::all();
        $this->waktuSiswa  = WaktuMahasiswa::all();
    }

    public function index(){
        $data_jadwal = DB::table("jadwal")
                    ->leftJoin('harimahasiswa','jadwal.waktu_mahasiswa','=','harimahasiswa.id')
                    ->leftJoin('mahasiswa','harimahasiswa.id_mahasiswa','=','mahasiswa.id')
                    ->leftJoin('haripenguji','jadwal.waktu_penguji','=','haripenguji.id')
                    ->leftJoin('penguji','haripenguji.id_penguji','=','penguji.id')
                    ->leftJoin('ruangan','jadwal.ruangan','=','ruangan.id')
                    ->leftJoin('waktusidang','jadwal.waktu','=','waktusidang.id')
                    ->leftJoin('hari','waktusidang.hari','=','hari.id')
                    ->select("mahasiswa.nim","mahasiswa.nama_mahasiswa","penguji.nip","mahasiswa.jdl_skripsi","penguji.nama_penguji","ruangan.nama_ruangan","hari.nama_hari","waktusidang.mulai","waktusidang.selesai","waktusidang.sesi")
                    ->orderBy('hari.id')
                    ->orderBy('waktusidang.mulai')
                    ->get();
        return view('jadwal.index', compact('data_jadwal'));
    }
    public function generate()
    {
        $logs = $this->show_log ? $this->console : "";   
        return view('jadwal.generate',compact("logs"));
    }

    public function log(){
        $log = DB::table('logs')->orderBy('id', 'desc')->first();
        return view('jadwal.log',compact("log"));
    }

    function initCalculate(Request $param)
    {
        ini_set('memory_limit', '128M');
        ini_set('max_execution_time', 300);
        $_val = $param->all();
        $this->num_crommosom = $_val["jumlah_kromosom"];
        $this->max_generation = $_val["max_generation"];
        $this->crossover_rate = $_val["crossOver"];    
        $this->mutation_rate = $_val["mutation"];
        $this->show_log = $_val["debug"];
        $this->time_start = microtime(true);
        $this->generate_crommosom();

        while (($this->generation < $this->max_generation) && $this->success == false) {
            $this->console .="<pre style='font-size:0.8em'>";
            $this->generation++;
            $this->console .= "<h4>Generasi ke-$this->generation</h4>";
            $this->show_crommosom();
            $this->calculate_all_fitness();
            $this->show_fitness();
            if (!$this->success) {
                $this->get_com_pro();
                $this->selection();
                $this->show_crommosom();
                $this->show_fitness();
            }
            if (!$this->success) {
                $this->crossover();
                $this->show_crommosom();
                $this->show_fitness();
            }

            if (!$this->success) {
                $this->mutation();
                $this->show_crommosom();
                $this->show_fitness();
            }
            $this->console .="</pre>";
        }
        $this->save_result();
        $this->time_end = microtime(true);
        $time = $this->time_end - $this->time_start;
        $_number_generated = DB::table('logs')->orderBy('id', 'desc')->first();
        $this->console .="\r\n\r\n<h2> Number Generate-".((!empty($_number_generated)? $_number_generated->id + 1 : 1))."</h2>";
        $this->console .="<pre style='font-size:0.8em'>\r\nFITNESS TERBAIK: $this->best_fitness";
        $this->console .="\r\nExecution Time: $time seconds";
        $this->console .="\r\nMemory Usage: " . memory_get_usage() / 1024 . ' kilo bytes';
        $this->console .="\r\nGENERASI: $this->generation";
        $this->console .="\r\nCROMOSSOM TERBAIK:  " . $this->print_cros($this->best_cromossom) . "</pre>";
        
        if(isset($_val["debug"])){
            try{
                DB::table("logs")->insert([
                    "logs" => $this->console
                ]);
             }catch(\Exception $e){
                $this->console .="\r\n\r\n<b>Data Terlalu Besar (tidak bisa menyimpan semua logs)</b>";
                $console2  ="\r\n\r\n<h2> Number Generate-".((!empty($_number_generated)? $_number_generated->id + 1 : 1))."</h2>";
                $console2 .="\r\n\r\n<b>Data Terlalu Besar (tidak bisa menyimpan semua logs)</b>";
                $console2 .="<pre style='font-size:0.8em'>\r\nFITNESS TERBAIK: $this->best_fitness";
                $console2 .="\r\nExecution Time: $time seconds";
                $console2 .="\r\nMemory Usage: " . memory_get_usage() / 1024 . ' kilo bytes';
                $console2 .="\r\nGENERASI: $this->generation";
                $console2 .="\r\nCROMOSSOM TERBAIK:  " . $this->print_cros($this->best_cromossom) . "</pre>";
                DB::table("logs")->insert([
                    "logs" => $console2
                ]);
                $logs = $this->show_log ? $this->console : "";   
                return view('jadwal.generate',compact("logs"));
            }
        }
        return redirect('jadwal');
    }

    function save_result()
    {
        DB::table("jadwal")->truncate();
        foreach ($this->best_cromossom as $key => $val) {
            if(isset( $this->ruang[$val["ruang"]]) && $this->currentUsed["waktu"][$val["waktuSiswa"]][$val["waktu"]] && $this->waktuSiswa[$val["waktuSiswa"]] && $this->currentUsed["dosen"][$val["waktuSiswa"]][$val["dosen"]]){
                DB::table("jadwal")->insert([
                    "waktu_penguji" => $this->currentUsed["dosen"][$val["waktuSiswa"]][$val["dosen"]]->id,
                    "waktu_mahasiswa" => $this->waktuSiswa[$val["waktuSiswa"]]->id,
                    "waktu" => $this->currentUsed["waktu"][$val["waktuSiswa"]][$val["waktu"]]->id,
                    "ruangan" => $this->ruang[$val["ruang"]]->id
                ]);
            }
        }
        reset($this->best_cromossom);
    }

    function generate_crommosom()
    {
        $numb = 0;
        while ($numb < $this->num_crommosom) {
            $cro = $this->get_rand_crommosom();
            $this->crommosom[] = $cro;
            $this->fitness[] = 0;
            $numb++;
        }
    }

    function get_rand_crommosom()
    {
        $result = array();
        foreach ($this->waktuSiswa as $key => $value) {
            $last_key = array_key_last($result);
            /* If you want order the time is ASC uncomment code in bellow but problem is so slowly application running */
            // $_xuS = DB::table("harimahasiswa")->where("id_hari",$value->id_hari)->count();
            // $this->currentUsed["waktu"][$key] = WaktuSidang::whereRaw('hari = ?', [$value->id_hari])->offset(0)->limit($_xuS)->orderBy("mulai","ASC")->get();
            $this->currentUsed["waktu"][$key] = WaktuSidang::whereRaw('hari = ?', [$value->id_hari])->get();
            $this->currentUsed["dosen"][$key] = WaktuPenguji::whereRaw('id_hari = ?', [$value->id_hari])->get();
            if(!$this->currentUsed["waktu"][$key]->isEmpty() && !$this->currentUsed["dosen"][$key]->isEmpty()){
                $_key = null;
                if(!empty($result) && $last_key !== null) {
                    $_key = $last_key + 1;
                } else{
                    $_key = 0;
                }
                $result[$_key]['waktuSiswa'] =  $key;
                $result[$_key]['dosen'] = rand(0, count($this->currentUsed["dosen"][$key]) - 1);
                $result[$_key]['ruang'] = rand(0, count($this->ruang) - 1);
                $result[$_key]['waktu'] = rand(0, count($this->currentUsed["waktu"][$key]) - 1);
            }
        }
        return $result;
    }

    function show_crommosom()
    {
        $cros = $this->crommosom;

        $a = array();
        foreach ($cros as $key => $val) {
            $a[] =  $this->print_cros($val, $key);
        }

        $this->console .= implode(" \r\n", $a) . "\r\n";
    }

    function print_cros($val = array(), $key = 0)
    {

        $arr = array();
        foreach ($val as $k => $v) {
            $arr[] = '[' . implode(',', $v) . ']';
        }
        return "\r\nKromosom[$key]: (" . implode(',', $arr) . ")";
    }

    function calculate_all_fitness()
    {
        foreach ($this->crommosom as $key => $val) {
            $this->calculate_fitness($key);
        }
    }

    function calculate_fitness($key)
    {
        $cro = $this->crommosom[$key];
        $penguji = $this->filter_penguji($cro);
        $waktu = $this->filter_waktu($cro);
        $ruang = $this->filter_ruang($cro);
        $f['desc'] = "1/(1  $penguji+$ruang+$waktu)";
        $f['nilai'] = 1 / (1 +   $penguji + $ruang + $waktu);
        if ($f['nilai'] == 1) 
            $this->success = false;

        if ($f['nilai'] > $this->best_fitness) {
            $this->best_fitness = $f['nilai'];
            $this->best_cromossom = $this->crommosom[$key];
        }

        $this->fitness[$key] = $f;
        return $f;
    }

    function filter_penguji($crom = array())
    {
        $clash = 0;
        $count = count($crom);
        for ($a = 0; $a < $count - 1; $a++) {
            for ($b = $a + 1; $b < $count; $b++) {
                $dosen = $this->currentUsed["dosen"][$crom[$a]['waktuSiswa']][$crom[$a]['dosen']];
                $dosen2 = $this->currentUsed["dosen"][$crom[$b]['waktuSiswa']][$crom[$b]['dosen']];
                if ($dosen->id_penguji == $dosen2->id_penguji && $dosen->id_hari == $dosen2->id_hari) {
                    if($this->is_time_clash($crom[$a], $crom[$b])){
                        $clash ++;
                    }
                }
            }
        }
        return $clash;
    }

    function filter_waktu($crom = array())
    {
        $clash = 0;
        $count = count($crom);
        for ($a = 0; $a < $count - 1; $a++) {
            for ($b = $a + 1; $b < $count; $b++) {
                $waktu = $this->currentUsed["waktu"][$crom[$a]['waktuSiswa']][$crom[$a]['waktu']];
                $waktu2 = $this->currentUsed["waktu"][$crom[$b]['waktuSiswa']][$crom[$b]['waktu']];
                if ($waktu->hari == $waktu2->hari) {
                      if($this->is_time_clash($crom[$a], $crom[$b])){
                        $clash ++;
                    }
                }
            }
        }
        return $clash;
    }
    
    function filter_ruang($crom = array())
    {
        $clash = 0;
        $count = count($crom);
        for ($a = 0; $a < $count - 1; $a++) {
            for ($b = $a + 1; $b < $count; $b++) {
                if($crom[$a]['ruang'] == $crom[$b]['ruang']){
                    if($this->is_time_clash($crom[$a], $crom[$b])){
                        $clash ++;
                    }
                }
            }
        }
        return $clash;
    }

    function show_fitness()
    {
        foreach ($this->fitness as $key => $fit) {
            $this->console .= "\r\nF[$key]: $fit[desc] = $fit[nilai] \r\n";
        }
        $this->get_total_fitness();
        $this->console .= "\r\nTotal F: " . $this->total_fitness . "\r\n";
    }

    function get_total_fitness()
    {
        $this->total_fitness = 0;
        foreach ($this->fitness as $val) {
            $this->total_fitness += $val['nilai'];
        }
        return $this->total_fitness;
    }

    function get_com_pro()
    {

        $this->get_probability();

        $this->com_pro = array();
        $x = 0;
        foreach ($this->probability as $key => $val) {
            $x += $val;
            $this->com_pro[] = $x;
            $this->console .= "\r\nPK[$key] : $x \r\n";
        }
        $this->com_pro;
    }
    function get_probability()
    {
        $this->probability = array();
        foreach ($this->fitness as $key => $val) {
            $x = $val['nilai'] / $this->total_fitness;
            $this->probability[] = $x;
            $this->console .= "P[$key] : $x \r\n";
        }
        $this->console .= "\r\nTotal P: " . array_sum($this->probability) . "\r\n";
        return $this->probability;
    }

    function selection()
    {
        $this->console .= "<h4>Seleksi generasi ke-$this->generation</h4>";
        $this->get_rand();
        $new_cro = array();
        foreach ($this->rand as $key => $val) {
            $k = $this->choose_selection($val);
            $new_cro[$key] = $this->crommosom[$k];
            $this->fitness[$key] = $this->fitness[$val];
            $this->console .= "\r\nK[$key] = K[$k] \r\n";
        }
        $this->crommosom = $new_cro;
    }

    function get_rand()
    {
        $this->rand = array();
        foreach ($this->fitness as $key => $val) {
            $r = mt_rand() / mt_getrandmax();
            $this->rand[] = $r;
            $this->console .= "\r\nR[$key] : $r \r\n";
        }
    }


    function choose_selection($rand_numb = 0)
    {
        foreach ($this->com_pro as $key => $val) {
            if ($rand_numb <= $val)
                return $key;
        }
    }


    /*CrossOver*/
    function crossover()
    {
        $this->console .= "<h4>Pindah silang generasi ke-$this->generation</h4>";
        $parent = array();

        foreach ($this->crommosom as $key => $val) {
            $rnd = mt_rand() / mt_getrandmax();
            if ($rnd <= $this->crossover_rate / 100)
                $parent[] = $key;
        }
        foreach ($parent as $key => $val) {
            $this->console .= "Parent[$key] : $val \r\n";
        }

        $parent = $parent;
        $c = count($parent);

        if ($c > 1) {
            for ($a = 0; $a < $c - 1; $a++) {
                $new_cro[$parent[$a]] = $this->get_crossover($parent[$a],  $parent[$a + 1]);
            }
            $new_cro[$parent[$c - 1]] = $this->get_crossover($parent[$c - 1],  $parent[0]);

            foreach ($new_cro as $key => $val) {
                $this->crommosom[$key] = $val;
                $this->calculate_fitness($key);
            }
        }
    }

    function get_crossover($key1, $key2)
    {
        $cro1 = $this->crommosom[$key1];
        $cro2 = $this->crommosom[$key2];

        $offspring = rand(0, count($cro1) - 2);
        $new_cro = array();
        for ($a = 0; $a < count($cro1); $a++) {
            if ($a <= $offspring)
                $new_cro[] =  $cro1[$a];
            else
                $new_cro[] =  $cro2[$a];
        }

        $this->console .= "Offspring: $offspring \r\n";

        return $new_cro;
    }

    /*Mutation*/
    function mutation()
    {
        $this->console .= "<h4>Mutasi generasi ke-$this->generation</h4>";
        $gen_per_cro = count($this->waktuSiswa);
        $total_gen = count($this->crommosom) * $gen_per_cro;
        $total_mutation = ceil($this->mutation_rate / 100 * $total_gen);

        for ($a = 1; $a <= $total_mutation; $a++) {
            $val = rand(1, $total_gen);

            $cro_index = ceil($val / $gen_per_cro) - 1;
            $gen_index = (($val - 1)  % $gen_per_cro);
            $this->console .= "$val : [$cro_index, $gen_index]\r\n";
            $this->crommosom[$cro_index][$gen_index]['ruang'] = rand(0, count($this->ruang) - 1);
            $this->crommosom[$cro_index][$gen_index]['waktu'] = rand(0, count($this->currentUsed["waktu"][$this->crommosom[$cro_index][$gen_index]["waktuSiswa"]]) - 1);
            $this->crommosom[$cro_index][$gen_index]['dosen'] = rand(0, count($this->currentUsed["dosen"][$this->crommosom[$cro_index][$gen_index]["waktuSiswa"]]) - 1);
            $this->fitness[$cro_index] = $this->get_fitness($cro_index);

            if ($this->success)
                return;
        }
        return false;
    }

    function get_fitness($key)
    {
        $cro = $this->crommosom[$key];
        $penguji = $this->filter_penguji($cro);
        $siswa = $this->filter_waktu($cro);
        $ruang = $this->filter_ruang($cro);

        $f['desc'] = "1/(1+$penguji+$ruang + $siswa)";
        $f['nilai'] = 1 / (1 + $penguji + $ruang + $siswa);

        if ($f['nilai'] == 1) 
            $this->success = true;

        if ($f['nilai'] > $this->best_fitness) {
            $this->best_fitness = $f['nilai'];
            $this->best_cromossom = $this->crommosom[$key];
        }

        $this->fitness[$key] = $f;
        return $f;
    }


    // Make Group Classsing data 
    function is_time_clash($gen1, $gen2)
    {
        $is_clash = 0;
        $waktu1 =$this->currentUsed["waktu"][$gen1["waktuSiswa"]][$gen1['waktu']];
        $waktu2 =$this->currentUsed["waktu"][$gen2["waktuSiswa"]][$gen2['waktu']];
        $key1 = $waktu1->id. '_' . $gen1['waktuSiswa'];
        $key2 = $waktu2->id. '_' . $gen2['waktuSiswa'];

        /** jika belum ada di cache */
        if (!isset($this->_timeclash[$key1][$key2])) {
            if ($waktu1->hari == $waktu2->hari) {
                $a_awal = $this->_strtotime($waktu1->mulai);
                $a_akhir =$this->_strtotime($waktu1->selesai);

                $b_awal = $this->_strtotime($waktu2->mulai);
                $b_akhir = $this->_strtotime($waktu2->selesai);

                if ($a_awal == $b_awal) {
                    $is_clash = 1;
                } else if ($a_awal > $b_awal && $a_awal < $b_akhir) {
                    $is_clash = 1;
                } else if ($a_akhir > $b_awal && $a_akhir < $b_akhir) {
                    $is_clash = 1;
                } else if ($b_awal > $a_awal && $b_awal < $a_akhir) {
                    $is_clash = 1;
                } else if ($b_akhir > $a_awal && $b_akhir < $a_akhir) {
                    $is_clash = 1;
                }
            }
        }
        /** jika sudah ada di cache */
        else {
            return $this->_timeclash[$key1][$key2];
        }

        $this->_timeclash[$key1][$key2] = $is_clash;
        $this->_timeclash[$key2][$key1] = $is_clash;

        return $this->_timeclash[$key1][$key2];
    }
    function _strtotime($nama_jam)
    {
        if(!isset($this->_strtotime['s'.$nama_jam]))
            $this->_strtotime['s'.$nama_jam] = strtotime($nama_jam);
                    
        return $this->_strtotime['s'.$nama_jam];                
    }                 
}
