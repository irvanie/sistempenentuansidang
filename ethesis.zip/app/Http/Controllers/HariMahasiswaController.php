<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Mahasiswa;
use App\Http\Requests\WaktuMahasiswaRequest;
use App\Hari;
use Storage;
use Session;
use App\WaktuMahasiswa;
use Illuminate\Support\Facades\DB;

class HariMahasiswaController extends Controller
{
    public function __construct() {
        $this->middleware('auth');
        $this->middleware('mahasiswa');
        
    }

    /*
    | -------------------------------------------------------------------------------------------------------
    | INDEX
    | -------------------------------------------------------------------------------------------------------
    */
    public function index() {
        $waktumahasiswa_list = WaktuMahasiswa::groupBy("id_mahasiswa")->get();
        $jumlah_hari = WaktuMahasiswa::count();
        return view('waktumahasiswa.index', compact('waktumahasiswa_list', 'jumlah_hari'));

    }

    public function create() {
        return view('waktumahasiswa.create');
    }

    public function store(WaktuMahasiswaRequest $request) {

    	$input = $request->all();
        // Insert  waktu mahasiswa.
        foreach ($input["id_hari"] as  $value) {
            $dataPost = array(
                "id_mahasiswa" => $input["id_mahasiswa"],
                "id_hari" => $value,
            );
            WaktuMahasiswa::create($dataPost);
        }
        // Flass message.
        Session::flash('flash_message', 'Data Hari Mahasiswa berhasil disimpan.');

        return redirect('waktumahasiswa');
    }

    public function edit($id) {
        $waktumahasiswa = DB::table("mahasiswa")->where('mahasiswa.id',"=",$id)
                        ->leftJoin('harimahasiswa','mahasiswa.id','=','harimahasiswa.id_mahasiswa')
                        ->leftJoin('hari','harimahasiswa.id_hari','=','hari.id')
                        ->groupBy('mahasiswa.id')
                        ->select("mahasiswa.id",DB::raw("group_concat(hari.nama_hari) as hari"))
                        ->get()[0];
        return view('waktumahasiswa.edit', compact('waktumahasiswa'));
    }

    public function update(WaktuMahasiswaRequest $request) {
        $input = $request->all();
        DB::table("harimahasiswa")->where('id_mahasiswa','=',$input["id_mahasiswa"])->delete();
        // Insert  waktu penguji.
        foreach ($input["id_hari"] as  $value) {
            $dataPost = array(
                "id_mahasiswa" => $input["id_mahasiswa"],
                "id_hari" => $value,
            );
            WaktuMahasiswa::create($dataPost);
        }
        Session::flash('flash_message', 'Data Waktu Mahasiswa berhasil diupdate.');
        return redirect('waktumahasiswa');
    }

    public function destroy($id) {
        DB::table("harimahasiswa")->where('id_mahasiswa','=',$id)->delete();
        Session::flash('flash_message', 'Data Waktu Mahasiswa berhasil dihapus.');
        Session::flash('penting', true);
        return redirect('waktumahasiswa');
    }
}
