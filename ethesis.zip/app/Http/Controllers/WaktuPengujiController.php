<?php

namespace App\Http\Controllers;

use App\Hari;
use Illuminate\Http\Request;
use App\Http\Requests\WaktuPengujiRequest;
use App\Penguji;
use App\WaktuPenguji;
use Illuminate\Support\Facades\DB;
use Storage;
use Session;

class WaktuPengujiController extends Controller
{
    
    public function __construct() {
        $this->middleware('auth');
        $this->middleware('admin');
        
    }

    /*
    | -------------------------------------------------------------------------------------------------------
    | INDEX
    | -------------------------------------------------------------------------------------------------------
    */
    public function index() {
        $waktupenguji_list = WaktuPenguji::groupBy("id_penguji")->get();
        $jumlah_waktupenguji = WaktuPenguji::count();
        return view('waktupenguji.index', compact('waktupenguji_list', 'jumlah_waktupenguji'));

    }

    public function create() {
        return view('waktupenguji.create');
    }

    public function store(WaktuPengujiRequest $request) {

    	$input = $request->all();
        // Insert  waktu penguji.
        foreach ($input["hari"] as  $value) {
            $dataPost = array(
                "id_penguji" => $input["id_penguji"],
                "id_hari" => $value,
            );
            WaktuPenguji::create($dataPost);
        }

        // Flass message.
        Session::flash('flash_message', 'Data Hari Penguji berhasil disimpan.');

        return redirect('waktupenguji');
    }

    public function edit($id) {
        $waktupenguji = DB::table("penguji")->where('penguji.id',"=",$id)
                            ->leftJoin('haripenguji','penguji.id','=','haripenguji.id_penguji')
                            ->leftJoin('hari','haripenguji.id_hari','=','hari.id')
                            ->groupBy('penguji.id')
                            ->select("penguji.id",DB::raw("group_concat(hari.nama_hari) as hari"))
                            ->get()[0];
        return view('waktupenguji.edit',compact("waktupenguji"));
    }

    public function update(WaktuPengujiRequest $request) {
        $input = $request->all();
        DB::table("haripenguji")->where('id_penguji','=',$input["id_penguji"])->delete();
        // Insert  waktu penguji.
        foreach ($input["hari"] as  $value) {
            $dataPost = array(
                "id_penguji" => $input["id_penguji"],
                "id_hari" => $value,
            );
            WaktuPenguji::create($dataPost);
        }
        Session::flash('flash_message', 'Data Waktu Penguji berhasil diupdate.');
        return redirect('waktupenguji');
    }

    public function destroy(Request $request, $id) {
        DB::table("haripenguji")->where('id_penguji','=',$id)->delete();
        // $waktupenguji->delete();
        Session::flash('flash_message', 'Data Waktu Penguji berhasil dihapus.');
        Session::flash('penting', true);
        return redirect('waktupenguji');
    }

}
