<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests\RuanganRequest;
use App\Ruangan;
use Session;

class RuanganController extends Controller
{
    public function __construct() {
        $this->middleware('auth');
        $this->middleware('admin');
    }

    public function index() {
        $ruangan_list = Ruangan::all();
        return view('ruangan.index', compact('ruangan_list'));
    }

    public function create() {
        return view('ruangan.create');
    }

    public function store(RuanganRequest $request) {
        Ruangan::create($request->all());
        Session::flash('flash_message', 'Data Ruangan berhasil disimpan.');
        return redirect('ruangan');
    }

    public function edit(Ruangan $ruangan) {
        return view('ruangan.edit', compact('ruangan'));
    }

    public function update(Ruangan $ruangan, RuanganRequest $request) {
        $ruangan->update($request->all());
        Session::flash('flash_message', 'Data Ruangan berhasil diupdate.');
        return redirect('ruangan');
    }

    public function destroy(Ruangan $ruangan) {
        $ruangan->delete();
        Session::flash('flash_message', 'Data Ruangan berhasil dihapus.');
        Session::flash('penting', true);
        return redirect('ruangan');
    }
}
