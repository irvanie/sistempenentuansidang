<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Penguji;
use App\Http\Requests\PengujiRequest;
use Illuminate\Support\Facades\Storage;
use Session;

class PengujiController extends Controller
{
    public function __construct() {
        $this->middleware('auth');
        $this->middleware('penguji');
    }

    /*
    | -------------------------------------------------------------------------------------------------------
    | INDEX
    | -------------------------------------------------------------------------------------------------------
    */
    public function index() {
        $penguji_list   = Penguji::paginate(5);
        $jumlah_penguji = Penguji::count();
        return view('penguji.index', compact('penguji_list', 'jumlah_penguji'));
    }


    /*
    | -------------------------------------------------------------------------------------------------------
    | SHOW DETAIL
    | -------------------------------------------------------------------------------------------------------
    */
    public function show(Penguji $penguji) {
        return view('penguji.show', compact('penguji'));
    }


    /*
    | -------------------------------------------------------------------------------------------------------
    | CREATE
    | -------------------------------------------------------------------------------------------------------
    */
    public function create() {
        return view('penguji.create');
    }


    /*
    | -------------------------------------------------------------------------------------------------------
    | EDIT
    | -------------------------------------------------------------------------------------------------------
    */
    public function edit(Penguji $penguji) {
        

        return view('penguji.edit', compact('penguji'));
    }


    /*
    | -------------------------------------------------------------------------------------------------------
    | CREATE
    | -------------------------------------------------------------------------------------------------------
    */
    public function store(PengujiRequest $request) {
        $input = $request->all();

        // Upload foto.
        if ($request->hasFile('foto')) {
            $input['foto'] = $this->uploadFoto($request);
        }

        // Insert penguji.
        $penguji = Penguji::create($input);

       
        // Flass message.
        Session::flash('flash_message', 'Data penguji berhasil disimpan.');

        return redirect('penguji');
    }


    /*
    | -------------------------------------------------------------------------------------------------------
    | UPDATE
    | -------------------------------------------------------------------------------------------------------
    */
    public function update(Penguji $penguji, PengujiRequest $request) {
        $input = $request->all();

        // Update foto.
        if ($request->hasFile('foto')) {
            $input['foto'] = $this->updateFoto($penguji, $request);
        }

        // Update penguji.
        $penguji->update($input);

        // Flash message.
        Session::flash('flash_message', 'Data penguji berhasil diupdate.');

        return redirect('penguji');
    }


    /*
    | -------------------------------------------------------------------------------------------------------
    | DESTROY / DELETE
    | -------------------------------------------------------------------------------------------------------
    */
    public function destroy(Penguji $penguji) {
        // Hapus foto kalau ada.
        $this->hapusFoto($penguji);

        $penguji->delete();

        // Flash message.
        Session::flash('flash_message', 'Data penguji berhasil dihapus.');
        Session::flash('penting', true);

        return redirect('penguji');
    }


    /*
    | -------------------------------------------------------------------------------------------------------
    | CARI
    | -------------------------------------------------------------------------------------------------------
    */
    // public function cari(Request $request) {
    //     $kata_kunci = trim($request->input('kata_kunci'));

    //     if (! empty($kata_kunci)) {
    //         $jenis_kelamin = $request->input('jenis_kelamin');
    //         $id_kelas = $request->input('id_kelas');

    //         // Query
    //         $query = Siswa::where('nama_siswa', 'LIKE', '%' . $kata_kunci . '%');
    //         (! empty($jenis_kelamin)) ? $query->JenisKelamin($jenis_kelamin) : '';
    //         (! empty($id_kelas)) ? $query->Kelas($id_kelas) : '';

    //         $siswa_list = $query->paginate(2);

    //         // URL Links pagination
    //         $pagination = (! empty($jenis_kelamin)) ? $siswa_list->appends(['jenis_kelamin' => $jenis_kelamin]) : '';
    //         $pagination = (! empty($id_kelas)) ? $pagination = $siswa_list->appends(['id_kelas' => $id_kelas]) : '';
    //         $pagination = $siswa_list->appends(['kata_kunci' => $kata_kunci]);

    //         $jumlah_siswa = $siswa_list->total();
    //         return view('siswa.index', compact('siswa_list', 'kata_kunci', 'pagination', 'jumlah_siswa', 'id_kelas', 'jenis_kelamin'));
    //     }

    //     return redirect('siswa');
    // }


    /*
    | -------------------------------------------------------------------------------------------------------
    | INSERT TELEPON
    | -------------------------------------------------------------------------------------------------------
    */
    // private function insertTelepon(Siswa $siswa, SiswaRequest $request) {
    //     $telepon = new Telepon;
    //     $telepon->nomor_telepon = $request->input('nomor_telepon');
    //     $siswa->telepon()->save($telepon);
    // }


    /*
    | -------------------------------------------------------------------------------------------------------
    | UPDATE TELEPON
    | -------------------------------------------------------------------------------------------------------
    */
    // private function updateTelepon(Siswa $siswa, SiswaRequest $request) {
    //     if ($siswa->telepon) {
    //         // Jika telp diisi, update.
    //         if ($request->filled('nomor_telepon')) {
    //             $telepon = $siswa->telepon;
    //             $telepon->nomor_telepon = $request->input('nomor_telepon');
    //             $siswa->telepon()->save($telepon);
    //         }
            // Jika telp tidak diisi, hapus.
        //     else {
        //         $siswa->telepon()->delete();
        //     }
        // }
        // Buat entry baru, jika sebelumnya tidak ada no telp.
    //     else {
    //         if ($request->filled('nomor_telepon')) {
    //             $telepon = new Telepon;
    //             $telepon->nomor_telepon = $request->input('nomor_telepon');
    //             $siswa->telepon()->save($telepon);
    //         }
    //     }
    // }


    /*
    | -------------------------------------------------------------------------------------------------------
    | UPLOAD FOTO
    | -------------------------------------------------------------------------------------------------------
    */
    private function uploadFoto(PengujiRequest $request) {
        $foto = $request->file('foto');
        $ext  = $foto->getClientOriginalExtension();

        if ($request->file('foto')->isValid()) {
            $foto_name   = date('YmdHis'). ".$ext";
            $request->file('foto')->move('fotoupload', $foto_name);
            return $foto_name;
        }
        return false;
    }

    /*
    | -------------------------------------------------------------------------------------------------------
    | UPDATE FOTO
    | -------------------------------------------------------------------------------------------------------
    */
    private function updateFoto(Penguji $penguji, PengujiRequest $request) {
        // Jika user mengisi foto.
        if ($request->hasFile('foto')) {
            // Hapus foto lama jika ada foto baru.
            $exist = Storage::disk('foto')->exists($penguji->foto);
            if (isset($penguji->foto) && $exist) {
                $delete = Storage::disk('foto')->delete($penguji->foto);
            }

            // Upload foto baru.
            $foto = $request->file('foto');
            $ext  = $foto->getClientOriginalExtension();
            if ($request->file('foto')->isValid()) {
                $foto_name   = date('YmdHis'). ".$ext";
                $upload_path = 'fotoupload';
                $request->file('foto')->move($upload_path, $foto_name);
                return $foto_name;
            }
        }
    }


    /*
    | -------------------------------------------------------------------------------------------------------
    | HAPUS FOTO
    | -------------------------------------------------------------------------------------------------------
    */
    private function hapusFoto(Penguji $penguji) {
        $is_foto_exist = Storage::disk('foto')->exists($penguji->foto);

        if ($is_foto_exist) {
            Storage::disk('foto')->delete($penguji->foto);
        }
    }
}
