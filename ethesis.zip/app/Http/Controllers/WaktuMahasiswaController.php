<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests\WaktuMahasiswaRequest;
use App\Mahasiswa;
use App\WaktuMahasiswa;
use App\Hari;
use Storage;
use Session;

class WaktuMahasiswaController extends Controller
{
    
    public function __construct() {
        $this->middleware('auth');
        
    }

    /*
    | -------------------------------------------------------------------------------------------------------
    | INDEX
    | -------------------------------------------------------------------------------------------------------
    */
    public function index() {
        $waktumahasiswa_list = WaktuMahasiswa::paginate(5);
        $jumlah_waktumahasiswa = WaktuMahasiswa::count();
        return view('waktumahasiswa.index', compact('waktumahasiswa_list', 'jumlah_waktumahasiswa'));

    }

    public function create() {
        return view('waktumahasiswa.create');
    }

    public function store(WaktuMahasiswaRequest $request) {

    	$input = $request->all();

        // Insert  waktu mahasiswa.
        $waktumahasiswa = WaktuMahasiswa::create($input);

        // Insert waktu.
        $waktumahasiswa->hari()->attach($request->input('hari'));


        // Flass message.
        Session::flash('flash_message', 'Data Hari Mahasiswa berhasil disimpan.');

        return redirect('waktumahasiswa');
    }

    public function edit(WaktuMahasiswa $waktumahasiswa) {
        return view('waktumahasiswa.edit', compact('waktumahasiswa'));
    }

    public function update(WaktuMahasiswa $waktumahasiswa, WaktuMahasiswaRequest $request) {
        $waktumahasiswa->update($request->all());

        // Update siswa.
        $waktumahasiswa->update($input);

        // Update hobi.
        $waktumahasiswa->hari()->sync($request->input('harimahasiswa'));

        Session::flash('flash_message', 'Data Waktu Mahasiswa berhasil diupdate.');
        return redirect('waktumahasiswa');
    }

    public function destroy(WaktuMahasiswa $waktumahasiswa) {
        $waktumahasiswa->delete();
        Session::flash('flash_message', 'Data Waktu Mahasiswa berhasil dihapus.');
        Session::flash('penting', true);
        return redirect('waktumahasiswa');
    }

}
