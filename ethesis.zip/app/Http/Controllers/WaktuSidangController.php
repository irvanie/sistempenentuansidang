<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests\WaktuSidangRequest;
use App\WaktuSidang;
use Session;

class WaktuSidangController extends Controller
{
    public function __construct() {
        $this->middleware('auth');
        $this->middleware('admin');   
    }

    public function index() {
        $waktusidang_list = WaktuSidang::all();
        return view('waktusidang.index', compact('waktusidang_list'));
    }

    public function create() {
        return view('waktusidang.create');
    }

    public function store(WaktuSidangRequest $request) {
        WaktuSidang::create($request->all());
        Session::flash('flash_message', 'Data Waktu Sidang berhasil disimpan.');
        return redirect('waktusidang');
    }

    public function edit(WaktuSidang $waktusidang) {
        return view('waktusidang.edit', compact('waktusidang'));
    }

    public function update(WaktuSidang $waktusidang, WaktuSidangRequest $request) {
        $waktusidang->update($request->all());
        Session::flash('flash_message', 'Data Waktu sidang berhasil diupdate.');
        return redirect('waktusidang');
    }

    public function destroy(WaktuSidang $waktusidang) {
        $waktusidang->delete();
        Session::flash('flash_message', 'Data Waktu sidang berhasil dihapus.');
        Session::flash('penting', true);
        return redirect('waktusidang');
    }
}
