<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class WaktuSidang extends Model
{
    protected $times = ['mulai','selesai'];
    protected $table = 'waktusidang';

    protected $fillable = [
        'hari',
        'mulai',
        'selesai',
        'sesi'
    ];


    public function haris() {
        return $this->belongsTo('App\Hari', 'hari');
    }
}
