<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class WaktuPenguji extends Model
{
    protected $table = 'haripenguji';
    protected $fillable = ['id_penguji','id_hari'];

    public function hari() {
        return $this->belongsToMany('App\Hari', 'haripenguji', 'id_penguji', 'id_hari');
    }

    public function penguji() {
        return $this->belongsTo('App\Penguji', 'id_penguji');
    }
}
