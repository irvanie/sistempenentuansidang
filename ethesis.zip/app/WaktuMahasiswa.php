<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class WaktuMahasiswa extends Model
{
    protected $table = 'harimahasiswa';
    protected $fillable = [
    	'id_mahasiswa',
		'id_hari'
		];

    public function hari() {
        return $this->belongsToMany('App\Hari', 'harimahasiswa', 'id_mahasiswa', 'id_hari');
    }

    public function mahasiswa() {
        return $this->belongsTo('App\Mahasiswa', 'id_mahasiswa');
    }
}
