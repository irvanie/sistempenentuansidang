<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use App\Mahasiswa;
use App\Hari;
use App\Penguji;

class FormSiswaServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap services.
     *
     * @return void
     */
    public function boot()
    {
        view()->composer('waktumahasiswa.form', function($view) {
            $view->with('list_mahasiswa', Mahasiswa::pluck('nama_mahasiswa', 'id'));
            $view->with('list_hari', Hari::pluck('nama_hari', 'id'));
        });

        view()->composer('waktupenguji.form', function($view) {
            $view->with('list_penguji', Penguji::pluck('nama_penguji', 'id'));
            $view->with('list_hari', Hari::pluck('nama_hari', 'id'));
        });

        view()->composer('waktusidang.form', function($view) {
            $view->with('list_hari', Hari::pluck('nama_hari', 'id'));
        });

        
    }

    /**
     * Register services.
     *
     * @return void
     */
    public function register()
    {
        //
    }
}
