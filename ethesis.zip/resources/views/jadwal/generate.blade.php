@extends('main')

@section('content')
    <div id="user">
    <h2>Generate Jadwal</h2>

    {!! Form::open(['url' => '/jadwal/submit']) !!}
    @include('jadwal.form', ['submitButtonText' => 'Generate Jadwal'])
    {!! Form::close() !!}
    </div>
@stop

@section('footer')
    @include('footer')
@stop