@extends('main')

@section('content')
    <div id="hari">
        @if (Auth::check())
        <div class="tombol-nav" style="margin-bottom: 10px;">
            <a href="{{ url('generate') }}" class="btn btn-primary">Generate Jadwal</a>
            <a href="{{ url('generate/log') }}" class="btn btn-success">view Logs</a>
        </div>
        @endif
        <h2>Jadwal Sidang</h2>

        @include('_partial.flash_message')

        @if (count($data_jadwal) > 0)
           <table class="table">
               <thead>
                   <tr>

                       <th>NIM</th>
                       <th>MAHASISWA</th>
                       <th>JUDUL SKRIPSI</th>
                       <th>PENGUJI</th>
                       <th>RUANGAN</th>
                       <th>HARI</th>
                       <th>SESI</th>
                       <th>WAKTU MULAI</th>
                       <th>WAKTU SELESAI</th>
                   </tr>
               </thead>
               <tbody>
                   
                   <?php foreach($data_jadwal as $data): ?>
                   <tr>
                       
                       <td>{{ $data->nim }}</td>
                       <td>{{ $data->nama_mahasiswa }}</td>
                       <td>{{ $data->jdl_skripsi }}</td>
                       <td>{{ $data->nama_penguji }}</td>
                       <td>{{ $data->nama_ruangan }}</td>
                       <td>{{ $data->nama_hari }}</td>
                       <td>{{ $data->sesi }}</td>
                       <td>{{ $data->mulai }}</td>
                       <td>{{ $data->selesai }}</td>

                   </tr>
                   <?php endforeach ?>
               </tbody>
           </table>
       @else
           <p>Tidak ada data Jadwal.</p>
       @endif

   </div> <!-- / #hobi -->
@stop

@section('footer')
  @include('footer')
@stop