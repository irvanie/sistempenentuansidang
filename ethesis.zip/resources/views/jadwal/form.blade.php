@if (isset($user))
    {!! Form::hidden('id', $user->id) !!}
@endif

{{-- Nama --}}
@if ($errors->any())
    <div class="form-group {{ $errors->has('jumlah_kromosom') ? 'has-error' : 'has-success' }}">
@else
    <div class="form-group">
@endif
    {!! Form::label('jumlah_kromosom', 'Jumlah Kromosom:', ['class' => 'control-label']) !!}
    {!! Form::number('jumlah_kromosom', 6, ['min'=>6,'max'=>500,'class' => 'form-control']) !!}
    @if ($errors->has('jumlah_kromosom'))
        <span class="help-block">{{ $errors->first('jumlah_kromosom') }}</span>
    @endif
    <p class="help-block">Masukkan antara 6-500</p>
    </div>
    </div>
@if ($errors->any())
    <div class="form-group {{ $errors->has('max_generation') ? 'has-error' : 'has-success' }}">
@else
    <div class="form-group">
@endif
    {!! Form::label('max_generation', 'Max Generasi:', ['class' => 'control-label']) !!}
    {!! Form::number('max_generation', 25, ['min'=>6,'max'=>500,'class' => 'form-control']) !!}
    @if ($errors->has('max_generation'))
        <span class="help-block">{{ $errors->first('max_generation') }}</span>
    @endif
    <p class="help-block">Masukkan antara 25-500</p>
    </div>
@if ($errors->any())
    <div class="form-group {{ $errors->has('crossOver') ? 'has-error' : 'has-success' }}">
@else
    <div class="form-group">
@endif
    {!! Form::label('crossOver', 'Crossover Rate:', ['class' => 'control-label']) !!}
    {!! Form::number('crossOver', 75, ['min'=>1,'max'=>100,'class' => 'form-control']) !!}
    @if ($errors->has('crossOver'))
        <span class="help-block">{{ $errors->first('crossOver') }}</span>
    @endif
    <p class="help-block">Masukkan antara 1-100</p>
    </div>
@if ($errors->any())
    <div class="form-group {{ $errors->has('mutation') ? 'has-error' : 'has-success' }}">
@else
    <div class="form-group">
@endif
    {!! Form::label('mutation', 'Mutation Rate:', ['class' => 'control-label']) !!}
    {!! Form::number('mutation', 25, ['min'=>1,'max'=>100,'class' => 'form-control']) !!}
    @if ($errors->has('mutation'))
        <span class="help-block">{{ $errors->first('mutation') }}</span>
    @endif
    <p class="help-block">Masukkan antara 1-100</p>
    </div>

<div class="checkbox">
    <label>{!! Form::checkbox('debug', true, true) !!} Simpan Logs Generate</label>
</div>
{{-- Submit Button --}}
<div class="form-group">
    {!! Form::submit($submitButtonText, ['class' => 'btn btn-primary form-control']) !!}
</div>

@if (!empty($logs))
    {!! $logs !!}
@endif