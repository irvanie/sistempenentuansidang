@extends('main')

@section('content')
    {!! $log->logs !!}
@stop


@section('footer')
   @include('footer')
@stop
