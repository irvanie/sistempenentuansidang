@extends('main')

@section('content')
<div id="haripenguji">
    <h2>Edit Hari</h2>

    {!! Form::model($haripenguji, ['method' => 'PATCH', 'action' => ['HariPengujiController@update', $hari->id]]) !!}
    @include('haripenguji.form', ['submitButtonText' => 'Update Hari'])
    {!! Form::close() !!}
</div>
@stop

@section('footer')
    @include('footer')
@stop