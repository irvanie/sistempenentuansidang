@extends('main')

@section('content')
     <div id="haripenguji">
         <h2>Hari</h2>

         @include('_partial.flash_message')

         @if (count($haripenguji_list) > 0)
            <table class="table">
                <thead>
                    <tr>

                        <th>Hari</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    
                    <?php foreach($haripenguji_list as $hari): ?>
                    <tr>
                        
                        <td>{{ $hari->nama_hari }}</td>
                        <td>
                            <div class="box-button">
                                {{ link_to('hari/' . $hari->id . '/edit', 'Edit', ['class' => 'btn btn-warning btn-sm']) }}
                            </div>
                            <div class="box-button">
                                {!! Form::open(['method' => 'DELETE', 'action' => ['HariPengujiController@destroy', $hari->id]]) !!}
                                    {!! Form::submit('Delete', ['class' => 'btn btn-danger btn-sm']) !!}
                                {!! Form::close() !!}
                            </div>
                        </td>
                    </tr>
                    <?php endforeach ?>
                </tbody>
            </table>
        @else
            <p>Tidak ada data hari.</p>
        @endif

        <div class="tombol-nav">
            <a href="haripenguji/create" class="btn btn-primary">Tambah Hari</a>
        </div>

    </div> <!-- / #hobi -->
@stop

@section('footer')
   @include('footer')
@stop