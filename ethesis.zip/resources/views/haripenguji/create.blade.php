@extends('main')

@section('content')
    <div id="haripenguji">
    <h2>Tambah Hari</h2>

    {!! Form::open(['url' => 'haripenguji']) !!}
    @include('haripenguji.form', ['submitButtonText' => 'Tambah Hari'])
    {!! Form::close() !!}
    </div>
@stop

@section('footer')
    @include('footer')
@stop