@extends('main')

@section('content')
<div class="container">
<h3 class="page-header">Dashboard</h3>

<div class="row">
          <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
          @php
            $jlh_mhsw= App\Mahasiswa::all();
          @endphp
            <div class="info-box blue-bg">
              <i class="fa fa-cloud-download"></i>
              <div class="count">{{count($jlh_mhsw)}}</div>
              <div class="title">Jumlah Mahasiswa</div>
            </div>
            <!--/.info-box-->
          </div>
          <!--/.col-->

          <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
          @php
            $jlh_pngj= App\Penguji::all();
          @endphp
            <div class="info-box brown-bg">
              <i class="fa fa-shopping-cart"></i>
              <div class="count">{{count($jlh_pngj)}}</div>
              <div class="title">Jumlah Penguji</div>
            </div>
            <!--/.info-box-->
          </div>
          <!--/.col-->

          <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
          @php
            $jlh_ruang= App\Ruangan::all();
          @endphp
            <div class="info-box dark-bg">
              <i class="fa fa-thumbs-o-up"></i>
              <div class="count">{{count($jlh_ruang)}}</div>
              <div class="title">Jumlah Ruangan</div>
            </div>
            <!--/.info-box-->
          </div>
          <!--/.col-->

          <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
          @php
            $jlh_user= App\User::all();
          @endphp
            <div class="info-box green-bg">
              <i class="fa fa-cubes"></i>
              <div class="count">{{count($jlh_user)}}</div>
              <div class="title">Jumlah User</div>
            </div>
            <!--/.info-box-->
          </div>
          <!--/.col-->

        </div>

</div>
@endsection
