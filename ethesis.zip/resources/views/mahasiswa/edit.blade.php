@extends('main')

@section('content')
    <div id="mahasiswa">
        <h2>Edit Data Mahasiswa</h2>

        {!! Form::model($mahasiswa, ['method' => 'PATCH', 'files' => true, 'action' => ['MahasiswaController@update', $mahasiswa->id]]) !!}
            @include('mahasiswa.form', ['submitButtonText' => 'Update Data Mahasiswa'])
        {!! Form::close() !!}
    </div>
@stop

@section('footer')
    @include('footer')
@stop