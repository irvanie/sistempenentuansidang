@if (isset($mahasiswa))
    {!! Form::hidden('id', $mahasiswa->id) !!}
@endif


<!-- NIM -->
@if ($errors->any())
<div class="form-group {{ $errors->has('nim') ? 'has-error' : 'has-success' }}">
@else
<div class="form-group">
@endif
     {!! Form::label('nim', 'NIM:', ['class' => 'control-label']) !!}
     {!! Form::text('nim', null, ['class' => 'form-control']) !!}
     @if ($errors->has('nim'))
        <span class="help-block">{{ $errors->first('nim') }}</span>
     @endif
</div>


<!-- NAMA -->
@if ($errors->any())
<div class="form-group {{ $errors->has('nama_mahasiswa') ? 'has-error' : 'has-success' }}">
@else
<div class="form-group">
@endif
     {!! Form::label('nama_mahasiswa', 'Nama:', ['class' => 'control-label']) !!}
     {!! Form::text('nama_mahasiswa', null, ['class' => 'form-control']) !!}
     @if ($errors->has('nama_mahasiswa'))
        <span class="help-block">{{ $errors->first('nama_mahasiswa') }}</span>
     @endif
</div>


<!-- TANGGAL LAHIR -->
@if ($errors->any())
<div class="form-group {{ $errors->has('tanggal_lahir') ? 'has-error' : 'has-success' }}">
@else
<div class="form-group">
@endif
    {!! Form::label('tanggal_lahir', 'Tanggal Lahir:', ['class' => 'control-label']) !!}
    {!! Form::date('tanggal_lahir', !empty($mahasiswa) ? $mahasiswa->tanggal_lahir->format('Y-m-d'): null, ['class' => 'form-control', 'id' => 'tanggal_lahir']) !!}
    @if ($errors->has('tanggal_lahir'))
        <span class="help-block">{{ $errors->first('tanggal_lahir') }}</span>
    @endif
</div>


<!-- JENIS KELAMIN -->
@if ($errors->any())
<div class="form-group {{ $errors->has('jenis_kelamin') ? 'has-error' : 'has-success' }}">
@else
<div class="form-group">
@endif
    {!! Form::label('jenis_kelamin', 'Jenis Kelamin:', ['class' => 'control-label']) !!}
    <div class="radio">
        <label>{!! Form::radio('jenis_kelamin', 'L') !!} Laki-laki</label>
    </div>
    <div class="radio">
        <label>{!! Form::radio('jenis_kelamin', 'P') !!} Perempuan</label>
    </div>
    @if ($errors->has('jenis_kelamin'))
        <span class="help-block">{{ $errors->first('jenis_kelamin') }}</span>
     @endif
</div>


<!-- Judul Skripsi -->
@if ($errors->any())
<div class="form-group {{ $errors->has('jdl_skripsi') ? 'has-error' : 'has-success' }}">
@else
<div class="form-group">
@endif
     {!! Form::label('jdl_skripsi', 'Judul Skripsi:', ['class' => 'control-label']) !!}
     {!! Form::text('jdl_skripsi', null, ['class' => 'form-control']) !!}
     @if ($errors->has('jdl_skripsi'))
        <span class="help-block">{{ $errors->first('jdl_skripsi') }}</span>
     @endif
</div>

<!-- FOTO -->
@if ($errors->any())
<div class="form-group {{ $errors->has('foto') ? 'has-error' : 'has-success' }}">
@else
<div class="form-group">
@endif
    {!! Form::label('foto', 'Foto:') !!}
    {!! Form::file('foto') !!}
    @if ($errors->has('foto'))
        <span class="help-block">{{ $errors->first('foto') }}</span>
    @endif

    <!-- MENAMPILKAN FOTO -->
    @if (isset($mahasiswa))
        @if (isset($mahasiswa->foto))
            <img src="{{ asset('fotoupload/' . $mahasiswa->foto) }}">
        @else
            @if ($mahasiswa->jenis_kelamin == 'L')
                <img src="{{ asset('fotoupload/dummymale.jpg') }}">
            @else
                <img src="{{ asset('fotoupload/dummyfemale.jpg') }}">
            @endif
        @endif
    @endif
</div>

<!-- SUBMIT -->
<div class="form-group">
    {!! Form::submit($submitButtonText, ['class' => 'btn btn-primary form-control']) !!}
</div>