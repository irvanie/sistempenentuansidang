@extends('main')

@section('content')
    <div id="mahasiswa">
        <h2>Tambah Data Mahasiswa</h2>

        {!! Form::open(['url' => 'mahasiswa', 'files' => true]) !!}
            @include('mahasiswa.form', ['submitButtonText' => 'Simpan Data Mahasiswa'])
        {!! Form::close() !!}
    </div>
@stop

@section('footer')
    @include('footer')
@stop