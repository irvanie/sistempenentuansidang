 @extends('main')

 @section('content')
     <div id="mahasiswa">
         <h2>Detail Data mahasiswa</h2>

         <table class="table table-striped">
             <tr>
                 <th>NIM</th>
                <td>{{ $mahasiswa->nim }}</td>
            </tr>
            <tr>
                <th>Nama</th>
                <td>{{ $mahasiswa->nama_mahasiswa }}</td>
            </tr>
            <tr>
                <th>Tanggal Lahir</th>
                <td>{{ $mahasiswa->tanggal_lahir->format('d-m-Y') }}</td>
            </tr>
            <tr>
                <th>Jenis Kelamin</th>
                <td>{{ $mahasiswa->jenis_kelamin }}</td>
            </tr>
            <tr>
                <th>Judul Skripsi</th>
                <td>{{ $mahasiswa->jdl_skripsi }}</td>
            </tr>
           
            <tr>
                <th>Foto</th>
                <td>
                    @if ($mahasiswa->foto)
                        <img src="{{ asset('fotoupload/'.$mahasiswa->foto) }}">
                    @else
                        @if ($mahasiswa->jenis_kelamin == 'L')
                            <img src="{{ asset('fotoupload/dummymale.jpg') }}">
                        @else
                            <img src="{{ asset('fotoupload/dummyfemale.jpg') }}">
                        @endif
                    @endif
                </td>
            </tr>
        </table>
    </div>
@stop

@section('footer')
    @include('footer')
@stop