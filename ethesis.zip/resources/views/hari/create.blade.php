@extends('main')

@section('content')
    <div id="hari">
    <h2>Tambah Hari</h2>

    {!! Form::open(['url' => 'hari']) !!}
    @include('hari.form', ['submitButtonText' => 'Tambah hari'])
    {!! Form::close() !!}
    </div>
@stop

@section('footer')
    @include('footer')
@stop