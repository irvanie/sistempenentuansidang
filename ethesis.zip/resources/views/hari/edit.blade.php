@extends('main')

@section('content')
<div id="hari">
    <h2>Edit Hari</h2>

    {!! Form::model($hari, ['method' => 'PATCH', 'action' => ['HariController@update', $hari->id]]) !!}
    @include('hari.form', ['submitButtonText' => 'Update Hari'])
    {!! Form::close() !!}
</div>
@stop

@section('footer')
    @include('footer')
@stop