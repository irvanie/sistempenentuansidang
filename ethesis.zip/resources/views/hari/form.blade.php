@if (isset($hari))
{!! Form::hidden('id', $hari->id) !!}
@endif

@if ($errors->any())
<div class="form-group {{ $errors->has('nama_hari') ? 'has-error' : 'has-success' }}">
@else
<div class="form-group">
@endif

{!! Form::label('nama_hari', 'Hari:', ['class' => 'control-label']) !!}
{!! Form::text('nama_hari', null, ['class' => 'form-control']) !!}

@if ($errors->has('nama_hari'))
<span class="help-block">{{ $errors->first('nama_hari') }}</span>
@endif
</div>

<div class="form-group">
{!! Form::submit($submitButtonText, ['class' => 'btn btn-primary form-control']) !!}
</div>